This library has only one class which requires two attributes, countryCode (ISO-2) and VAT number to be checked. 
As response you get dict like object with {countryCode, vatNumber, requestDate, valid, name, address}. All of the items in dict have string format.

